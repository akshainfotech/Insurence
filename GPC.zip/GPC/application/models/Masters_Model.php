<?php 
   class Masters_Model extends CI_Model {
	
      function __construct() { 
         parent::__construct(); 
      } 
   
      public function insertMake($data) { 
         if ($this->db->insert("vehicle_make", $data)) { 
            return true; 
         } 
      } 
   
      public function deleteMake($vehicle_make_name) {
		$name = urldecode($vehicle_make_name);
         $this->db->delete("vehicle_make", "vehicle_make_name =  '".$name."' ");
          
      } 
   
      public function updateMake($data,$vehicle_make_name) { 
        $this->db->set($data); 
        $this->db->where("vehicle_make_name", $vehicle_make_name); 
        $this->db->update("vehicle_make", $data); 
      } 
	  public function insertBrand($data) { 
         if ($this->db->insert("vehicle_brand", $data)) { 
            return true; 
         } 
      } 
	   public function updateBrand($data,$vehicle_brand_name) { 
        $this->db->set($data); 
        $this->db->where("vehicle_brand_name", $vehicle_brand_name); 
        $this->db->update("vehicle_brand", $data); 
      }
	  public function deleteBrand($vehicle_brand_name) {
		$name = urldecode($vehicle_brand_name);
         $this->db->delete("vehicle_brand", "vehicle_brand_name =  '".$name."' ");
          
      }
	  public function insertModel($data) { 
         if ($this->db->insert("vehicle_model", $data)) { 
            return true; 
         } 
      }
	  public function updateModel($data,$vehicle_model_name) { 
        $this->db->set($data); 
        $this->db->where("vehicle_model_name", $vehicle_model_name); 
        $this->db->update("vehicle_model", $data); 
      }
	  public function deleteModel($vehicle_model_name) {
		$name = urldecode($vehicle_model_name);
        $this->db->delete("vehicle_model", "vehicle_model_name =  '".$name."' ");
          
      }
	  public function insertType($data) { 
         if ($this->db->insert("vehicle_type", $data)) { 
            return true; 
         } 
      }
	  public function updateType($data,$vehicle_type_name) { 
        $this->db->set($data); 
        $this->db->where("vehicle_type_name", $vehicle_type_name); 
        $this->db->update("vehicle_type", $data); 
      }
	   public function deleteType($vehicle_type_name) {
		$name = urldecode($vehicle_type_name);
        $this->db->delete("vehicle_type", "vehicle_type_name =  '".$name."' ");
          
      }
	  public function insertColor($data) { 
         if ($this->db->insert("vehicle_color", $data)) { 
            return true; 
         } 
      }
	  public function updateColor($data,$vehicle_color_name) { 
        $this->db->set($data); 
        $this->db->where("vehicle_color_name", $vehicle_color_name); 
        $this->db->update("vehicle_color", $data); 
      }
	   public function deleteColor($vehicle_color_name) {
		$name = urldecode($vehicle_color_name);
        $this->db->delete("vehicle_color", "vehicle_color_name =  '".$name."' ");
          
      }
	  public function insertPromotion($data) { 
         if ($this->db->insert("promotions", $data)) { 
            return true; 
         } 
      }
	  public function updatePromotion($data,$promotion_name) { 
        $this->db->set($data); 
        $this->db->where("promotion_name", $promotion_name); 
        $this->db->update("promotions", $data); 
      }
	   public function deletePromotion($promotion_name) {
		$name = urldecode($promotion_name);
        $this->db->delete("promotions", "promotion_name =  '".$name."' ");
          
      }
      
   public function insertTax($data) { 
         if ($this->db->insert("tax", $data)) { 
            return true; 
         } 
      }
	  public function updateTax($data,$tax_name) { 
        $this->db->set($data); 
        $this->db->where("tax_name", $tax_name); 
        $this->db->update("tax", $data); 
      }
	   public function deleteTax($tax_name) {
		$name = urldecode($tax_name);
        $this->db->delete("tax", "tax_name =  '".$name."' ");
          
      }
   }
?> 
<footer class="main-footer">
      <!-- To the right -->
      <div class="pull-right hidden-xs">

      </div>
      <!-- Default to the left -->
      <strong>Copyright &copy; 2017
        <a href="#">GPC</a>.</strong> All rights reserved.
    </footer>
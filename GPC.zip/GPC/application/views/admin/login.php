<div class="login-box">
  <div class="login-logo">
    <a href="#"><b>GPC</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in</p>
      <?php 
          $attributes = array('class' => 'form-login' , 'autocomplete' => 'off');
          echo form_open('/index.php/admin/login/',$attributes); 
      ?> 
      <div class="form-group has-feedback">
        <input type="text" id="username" name="username" class="form-control" placeholder="username">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" id="password" name="password" class="form-control" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <!-- /.col -->
        <div class="form-group has-feedback">
          <div class="col-xs-4">
            <button type="submit" name="login" class="btn btn-primary btn-block btn-flat">Sign In</button>
          </div>
        </div>
        <!-- /.col -->
      </div>
      <br>
      <?php if($this->session->flashdata('message')!='') { ?>
        <div class="row">
          <div class="form-group has-feedback">
            <div class="alert alert-danger alert-dismissable">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
              <strong><?php echo $this->session->flashdata('message'); ?></strong>
            </div>
          </div>
        </div>
        <?php }  ?>
        <?php if(validation_errors()!='') { ?>
        <div class="row"> 
          <div class="form-group has-feedback">
            <div class="alert alert-danger alert-dismissable">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
              <strong><?php echo validation_errors(); ?> </strong>
            </div>
          </div>
        </div>
        <?php }  ?>
    </form>

    

  </div>
  <!-- /.login-box-body -->
</div>
<?php
Class Masters extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("vehicle_make");
	$this->db->order_by("vehicle_make_name", "asc");
	$query = $this->db->get(); 		
	$data['records'] = $query->result();
	$this->load->view('VehicleMake',$data);
	}
	public function insertMake()  
    {  
        $this->load->model('Masters_Model');
			
         $data = array( 
            'vehicle_make_name' => $this->input->post('addVehicleMake') 
            
         ); 
				$this->Masters_Model->insertMake($data);				
				$this->db->from("vehicle_make");
				$this->db->order_by("vehicle_make_name", "asc");
				$query = $this->db->get(); 		
				$data['records'] = $query->result();
				
				$this->load->view('VehicleMake',$data);	
				
    }
	public function updateMake(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			'vehicle_make_name' => $this->input->post('editVehicleMake') 
		 ); 			
		$vehicle_make_name = $this->input->post('vehicle_make_name'); 
		$this->Masters_Model->updateMake($data,$vehicle_make_name);
		$this->db->from("vehicle_make");
		$this->db->order_by("vehicle_make_name", "asc");
		$query = $this->db->get(); 		
		$data['records'] = $query->result();
		$this->load->view('VehicleMake',$data);	
	}
	public function deleteMake() { 
        $this->load->model('Masters_Model'); 
        $make_name = $this->uri->segment('3');
        $this->Masters_Model->deleteMake($make_name); 
		$this->db->from("vehicle_make");
		$this->db->order_by("vehicle_make_name", "asc");
		$query = $this->db->get(); 		
		$data['records'] = $query->result();
		$this->load->view('VehicleMake',$data);	
			
    }
	public function Brand(){
		
	$this->load->model('Masters_Model'); 
	$this->db->from("vehicle_make");
	$this->db->order_by("vehicle_make_name", "asc");
	$query = $this->db->get(); 		
	$data['makerecords'] = $query->result();
	
	
	$this->db->from("vehicle_brand");
	$this->db->order_by("vehicle_brand_name", "asc");
	$query = $this->db->get(); 		
	$data['brandrecords'] = $query->result();
	$this->load->view('VehicleBrand',$data);
		
	/*$brand_data = array( 
		'vehicle_make_name' => $this->input->post('vehicle_make_name'),
		'vehicle_brand_name' => $this->input->post('addVehicleBrand') 		
	); 
	$this->Masters_Model->insertBrand($brand_data);*/
	
				
	}
}

?>
<?php
Class MastersModel extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("vehicle_model");
	$this->db->order_by("vehicle_model_name", "asc");
	$query = $this->db->get(); 		
	$data['modelrecords'] = $query->result();
	$this->load->model('Masters_Model'); 
	$this->db->from("vehicle_brand");
	$this->db->order_by("vehicle_brand_name", "asc");
	$query = $this->db->get(); 		
	$data['brandrecords'] = $query->result();
	$this->load->view('VehicleModel',$data);
	}
	
	public function insertModel(){
	
	$this->load->model('Masters_Model');		
	$modeldata = array( 
		'vehicle_brand_name' => $this->input->post('vehicle_brand_name'),
		'vehicle_model_name' => $this->input->post('addVehicleModel') 		
	); 
	 
	$this->Masters_Model->insertModel($modeldata);
	
	$this->index();
		
	}
	public function updateModel(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			
			'vehicle_model_name' => $this->input->post('editVehicleModel') 
		 ); 			
		$vehicle_model_name =$this->input->post('vehicle_model_name');
		$this->Masters_Model->updateModel($data,$vehicle_model_name);
		$this->index();
	}
	public function deleteModel() { 
        $this->load->model('Masters_Model'); 
        $model_name = $this->uri->segment('3');
        $this->Masters_Model->deleteModel($model_name); 
		$this->index();	
			
    }
}

?>
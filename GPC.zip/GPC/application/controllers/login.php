<?php
Class login extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url'); 
    $this->load->database(); 
	
	
	}

	
	public function index() {
	
	$this->load->view('index');
	
	}
	public function process()  
    {  
        $user =$this->input->post('username');  
        $pass =$this->input->post('password');  
        if ($user=='admin' && $pass=='gpc@123')   
        {  
            
			$login_data = array('user'=>$user,
				'logged_in' => TRUE
				); 
            $this->session->set_userdata($login_data);  
            $this->load->view('Dashboard');  
        }  
        else{  
            $data['error'] = 'Your Account is Invalid';  
            $this->load->view('index', $data);  
        }  
    } 
	
	

}

?>
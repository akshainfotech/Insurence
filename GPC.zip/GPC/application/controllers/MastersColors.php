<?php
Class MastersColors extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("vehicle_color");
	$this->db->order_by("vehicle_color_name", "asc");
	$query = $this->db->get(); 		
	$data['colorrecords'] = $query->result();
	
	$this->load->view('VehicleColors',$data);
	}
	
	public function insertColor(){
	
	$this->load->model('Masters_Model');		
	$typedata = array( 
		'vehicle_color_name' => $this->input->post('addVehicleColor')
				
	); 
	 
	$this->Masters_Model->insertColor($typedata);
	
	$this->index();
		
	}
	public function updateColor(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			
			'vehicle_color_name' => $this->input->post('editVehicleColor') 
		 ); 			
		$vehicle_color_name =$this->input->post('vehicle_color_name');
		$this->Masters_Model->updateColor($data,$vehicle_color_name);
		$this->index();
	}
	public function deleteColor() { 
        $this->load->model('Masters_Model'); 
        $color_name = $this->uri->segment('3');
        $this->Masters_Model->deleteColor($color_name); 
		$this->index();	
			
    }
}

?>
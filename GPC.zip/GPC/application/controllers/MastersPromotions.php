<?php
Class MastersPromotions extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("promotions");
	$this->db->order_by("promotion_name", "asc");
	$query = $this->db->get(); 		
	$data['promotions'] = $query->result();
	
	$this->load->view('Promotions',$data);
	}
	
	public function insertPromotion(){
	
	$this->load->model('Masters_Model');		
	$prodata = array( 
		'promotion_name' => $this->input->post('promotion_name')
				
	); 
	 
	$this->Masters_Model->insertPromotion($prodata);
	
	$this->index();
		
	}
	public function updatePromotion(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			
			'promotion_name' => $this->input->post('editVehiclePromotion') 
		 ); 			
		$promotion_name =$this->input->post('promotions_name');
		$this->Masters_Model->updatePromotion($data,$promotion_name);
		$this->index();
	}
	public function deletePromotion() { 
        $this->load->model('Masters_Model'); 
        $pro_name = $this->uri->segment('3');
        $this->Masters_Model->deletePromotion($pro_name); 
		$this->index();	
			
    }
}

?>
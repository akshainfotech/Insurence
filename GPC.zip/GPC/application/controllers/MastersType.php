<?php
Class Masterstype extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("vehicle_type");
	$this->db->order_by("vehicle_type_name", "asc");
	$query = $this->db->get(); 		
	$data['typerecords'] = $query->result();
	
	$this->load->view('VehicleType',$data);
	}
	
	public function insertType(){
	
	$this->load->model('Masters_Model');		
	$typedata = array( 
		'vehicle_type_name' => $this->input->post('addVehicleType')
				
	); 
	 
	$this->Masters_Model->insertType($typedata);
	
	$this->index();
		
	}
	public function updateType(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			
			'vehicle_type_name' => $this->input->post('editVehicleType') 
		 ); 			
		$vehicle_type_name =$this->input->post('vehicle_type_name');
		$this->Masters_Model->updateType($data,$vehicle_type_name);
		$this->index();
	}
	public function deleteType() { 
        $this->load->model('Masters_Model'); 
        $type_name = $this->uri->segment('3');
        $this->Masters_Model->deleteType($type_name); 
		$this->index();	
			
    }
}

?>
<?php
Class MastersBrand extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("vehicle_brand");
	$this->db->order_by("vehicle_brand_name", "asc");
	$query = $this->db->get(); 		
	$data['brandrecords'] = $query->result();
	$this->load->model('Masters_Model'); 
	$this->db->from("vehicle_make");
	$this->db->order_by("vehicle_make_name", "asc");
	$query = $this->db->get(); 		
	$data['makerecords'] = $query->result();
	$this->load->view('VehicleBrand',$data);
	}
	
	public function Brand(){
	
	$this->load->model('Masters_Model');		
	$branddata = array( 
		'vehicle_make_name' => $this->input->post('vehicle_make_name'),
		'vehicle_brand_name' => $this->input->post('addVehicleBrand') 		
	); 
	 
	$this->Masters_Model->insertBrand($branddata);
	
	$this->db->from("vehicle_brand");
	$this->db->order_by("vehicle_brand_name", "asc");
	$query = $this->db->get(); 		
	$data['brandrecords'] = $query->result();
	$this->load->model('Masters_Model'); 
	$this->db->from("vehicle_make");
	$this->db->order_by("vehicle_make_name", "asc");
	$query = $this->db->get(); 		
	$data['makerecords'] = $query->result();
	$this->load->view('VehicleBrand',$data);		
	}
	public function updateBrand(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			
			'vehicle_brand_name' => $this->input->post('editVehicleBrand') 
		 ); 			
		$vehicle_brand_name =$this->input->post('vehicle_brand_name');
		$this->Masters_Model->updateBrand($data,$vehicle_brand_name);
		$this->db->from("vehicle_brand");
		$this->db->order_by("vehicle_brand_name", "asc");
		$query = $this->db->get(); 		
		$data['brandrecords'] = $query->result();
		$this->load->model('Masters_Model'); 
		$this->db->from("vehicle_make");
		$this->db->order_by("vehicle_make_name", "asc");
		$query = $this->db->get(); 		
		$data['makerecords'] = $query->result();
		$this->load->view('VehicleBrand',$data);
	}
	public function deleteBrand() { 
        $this->load->model('Masters_Model'); 
        $brand_name = $this->uri->segment('3');
        $this->Masters_Model->deleteBrand($brand_name); 
		$this->db->from("vehicle_brand");
		$this->db->order_by("vehicle_brand_name", "asc");
		$query = $this->db->get(); 		
		$data['brandrecords'] = $query->result();
		$this->load->model('Masters_Model'); 
		$this->db->from("vehicle_make");
		$this->db->order_by("vehicle_make_name", "asc");
		$query = $this->db->get(); 		
		$data['makerecords'] = $query->result();
		$this->load->view('VehicleBrand',$data);	
			
    }
}

?>
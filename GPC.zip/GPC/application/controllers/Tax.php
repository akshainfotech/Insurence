<?php
Class Tax extends CI_Controller {

	public function __construct() {
	parent::__construct();
	
	$this->load->library('session');
	$this->load->helper('url');
	$this->load->helper(array('form'));	
    $this->load->database(); 
	$this->load->library('form_validation');
	
	}

	
	public function index() {
	
	$this->db->from("tax");
	$this->db->order_by("tax_name", "asc");
	$query = $this->db->get(); 		
	$data['tax'] = $query->result();
	
	$this->load->view('Tax',$data);
	}
	
	public function insertTax(){
	
	$this->load->model('Masters_Model');		
	$taxdata = array( 
		'tax_name' => $this->input->post('tax_name')
				
	); 
	 
	$this->Masters_Model->insertTax($taxdata);
	
	$this->index();
		
	}
	public function updateTax(){
		
		$this->load->model('Masters_Model');		
		$data = array( 
			
			
			'tax_name' => $this->input->post('editVehicleTax') 
		 ); 			
		$tax_name =$this->input->post('select_tax_name');
		$this->Masters_Model->updateTax($data,$tax_name);
		$this->index();
	}
	public function deleteTax() { 
        $this->load->model('Masters_Model'); 
        $tax_name = $this->uri->segment('3');
        $this->Masters_Model->deleteTax($tax_name); 
		$this->index();	
			
    }
}

?>